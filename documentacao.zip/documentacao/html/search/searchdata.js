var indexSectionsWithContent =
{
  0: "bcdfmoprs",
  1: "bcfrs",
  2: "bcfmrs",
  3: "bcdfmoprs",
  4: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "related"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Amigas"
};

