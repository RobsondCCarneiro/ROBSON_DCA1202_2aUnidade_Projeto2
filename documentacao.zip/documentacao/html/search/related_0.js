var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../class_screen.html#aab6a2880746bfe1b7964817cc8f0989e',1,'Screen']]]
];
