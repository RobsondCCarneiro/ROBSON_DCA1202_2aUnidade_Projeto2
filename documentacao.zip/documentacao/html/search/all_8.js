var searchData=
[
  ['screen',['Screen',['../class_screen.html',1,'Screen'],['../class_screen.html#acb31ab18f39b1becad966f8385283d35',1,'Screen::Screen()']]],
  ['screen_2ecpp',['screen.cpp',['../screen_8cpp.html',1,'']]],
  ['screen_2eh',['screen.h',['../screen_8h.html',1,'']]],
  ['setbrush',['setBrush',['../class_screen.html#aebc4eb6cb5acf15a0f04c1494622ab23',1,'Screen']]],
  ['setpixel',['setPixel',['../class_screen.html#ae6bea81c57a22d226507c3c26fa95ee0',1,'Screen']]]
];
