var searchData=
[
  ['screen',['Screen',['../class_screen.html#acb31ab18f39b1becad966f8385283d35',1,'Screen']]],
  ['setbrush',['setBrush',['../class_screen.html#aebc4eb6cb5acf15a0f04c1494622ab23',1,'Screen']]],
  ['setpixel',['setPixel',['../class_screen.html#ae6bea81c57a22d226507c3c26fa95ee0',1,'Screen']]]
];
