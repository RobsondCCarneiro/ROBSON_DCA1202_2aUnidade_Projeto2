var searchData=
[
  ['circulo',['Circulo',['../class_circulo.html#abc019d9c6084efab817b66f68f281dba',1,'Circulo']]],
  ['clear',['clear',['../class_screen.html#a35e74266b2a04e37b354ceff7a5f1031',1,'Screen']]]
];
